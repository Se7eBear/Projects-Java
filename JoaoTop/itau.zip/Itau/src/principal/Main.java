package principal;

import alunos.Alunos;
import java.util.Scanner;

public class Main {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		Alunos joaozinho = new Alunos();

		joaozinho.SetNome("Joao");
                System.out.println(joaozinho.getNome());

}
}